// Helia Bayat    40223015
#include <stdio.h>
int main()
{
    int n, i, j;
    char A[100], B[100], C[100], D[100];
    printf("Enter tedade kalamate do zaban : ");
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        printf("\nkalamate moadel ra vared konid :");
        scanf("%s\t%s", A, B);
        printf("\n");
    }

    printf("Enter ebarat ba kalamate zabane aval : ");
    for (i = 0; i < n; i++)
        scanf("%c", C[i]);

    // to jomle rah boro
    i = 0;
    while (C[i] != ' ')
    {
        D[i] = C[i];
        i++;
    } // kalame aval tamoom shod
    return 0;
}